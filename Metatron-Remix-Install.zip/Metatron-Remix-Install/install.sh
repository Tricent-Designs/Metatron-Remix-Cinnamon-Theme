#!/bin/bash

# Determine the directory where this script is located
SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"

# Define source paths (inside the /data folder next to the script)
DATA_DIR="$SCRIPT_DIR/data"
STYLE_FILE="metatron-remix.styles"
SOURCE_STYLE="$DATA_DIR/$STYLE_FILE"
SOURCE_THEMES_DIR="$DATA_DIR/themes"

# Define system target paths
TARGET_STYLE_DIR="/usr/share/cinnamon/styles.d"
TARGET_THEMES_DIR="/usr/local/share/themes"

# 1. Process the .styles file
if [ -f "$SOURCE_STYLE" ]; then
    if [ ! -d "$TARGET_STYLE_DIR" ]; then
        echo "Creating target style directory..."
        sudo mkdir -p "$TARGET_STYLE_DIR"
    fi
    echo "Copying style: $STYLE_FILE -> $TARGET_STYLE_DIR"
    sudo cp "$SOURCE_STYLE" "$TARGET_STYLE_DIR/"
else
    echo "Warning: Style file '$STYLE_FILE' not found in $DATA_DIR"
fi

# 2. Process the themes folders
if [ -d "$SOURCE_THEMES_DIR" ]; then
    if [ ! -d "$TARGET_THEMES_DIR" ]; then
        echo "Creating target themes directory..."
        sudo mkdir -p "$TARGET_THEMES_DIR"
    fi

    # Loop through each item inside data/themes
    for theme in "$SOURCE_THEMES_DIR"/*; do
        if [ -d "$theme" ]; then
            theme_name=$(basename "$theme")
            echo "Copying theme: $theme_name -> $TARGET_THEMES_DIR"
            # Copy the entire folder recursively
            sudo cp -r "$theme" "$TARGET_THEMES_DIR/"
        fi
    done
else
    echo "Warning: Themes folder not found at $SOURCE_THEMES_DIR"
fi

# 3. Status Check
if [ $? -eq 0 ]; then
    echo "Installation completed successfully!"
else
    echo "An error occurred during the installation."
    exit 1
fi

