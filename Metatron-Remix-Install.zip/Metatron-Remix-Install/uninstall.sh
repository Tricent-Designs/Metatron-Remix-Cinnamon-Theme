#!/bin/bash

# Define system target paths
TARGET_STYLE_FILE="/usr/share/cinnamon/styles.d/metatron-remix.styles"
TARGET_THEMES_DIR="/usr/local/share/themes"

echo "Starting uninstallation process..."

# 1. Remove the specific styles file
if [ -f "$TARGET_STYLE_FILE" ]; then
    echo "Removing style file: $TARGET_STYLE_FILE"
    sudo rm "$TARGET_STYLE_FILE"
else
    echo "Style file already removed or not found."
fi

# 2. Clear everything inside the themes directory
if [ -d "$TARGET_THEMES_DIR" ]; then
    # Check if the folder is not empty before trying to delete contents
    if [ "$(ls -A "$TARGET_THEMES_DIR")" ]; then
        echo "Clearing all themes from: $TARGET_THEMES_DIR"
        # Deletes all folders and files inside the themes directory
        sudo rm -rf "$TARGET_THEMES_DIR"/*
    else
        echo "Themes directory is already empty."
    fi
else
    echo "Themes directory does not exist."
fi

# 3. Status Check
if [ $? -eq 0 ]; then
    echo "Uninstallation completed successfully!"
else
    echo "An error occurred during uninstallation."
    exit 1
fi

