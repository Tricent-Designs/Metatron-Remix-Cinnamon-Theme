# Metatron Remix Theme

This theme was developed for Linux Mint 22 "Zena". If you are using a different version, please ensure that the **Yaru icon themes** and the **DMZ cursor themes** are installed so that the theme works correctly.

> **IMPORTANT:** I am not liable for any damage that may occur during installation or uninstallation; use of the scripts is at your own risk.

---

## Installation

To install this theme, extract this folder to a location of your choice (e.g., `/home/user/Downloads/Metatron-Remix`), open the terminal, navigate to that directory, and run `./install.sh`:

```bash
cd /path/to/Metatron-Remix-Install
sudo ./install.sh
```

* **[INFO]** The `install.sh` script places all themes in `/usr/local/share/themes` and the style file in `/usr/share/cinnamon/styles.d`.
* **[FIX]** If the themes have any errors, press **Alt + F2**, type **r**, and press **Enter** — this will reload the Cinnamon environment.

---

## Uninstallation

> **[CAUTION]** If you wish to uninstall the theme using the `uninstall.sh` file, please proceed with caution: the script deletes all themes in the `/usr/local/share/themes` directory. This path is non-standard and most likely will be empty on most systems; however, should other themes be located there for any reason, **they will be deleted by the script**.

If you want to uninstall the theme, open the terminal, navigate to the corresponding directory, and run `./uninstall.sh`:

```bash
cd /path/to/Metatron-Remix-Install
sudo ./uninstall.sh
```

* **[INFO]** The `uninstall.sh` script deletes all themes in `/usr/local/share/themes` as well as the style file in `/usr/share/cinnamon/styles.d`.

---

## Support

A lot of work has gone into this theme; if you’d like to support me, you can find my donation addresses here:

* **BTC:** `bc1qcpw89aw9pt58vh3pmsthsal7dvk4pd5n8fd4zr`
* **ETH:** `0xC02ce490D2747760e2601969c1C8B6ED234779A9`
* **XRP:** `r4yZzzzMSDjQ5pcNHR5upu9mmPypB4nzNY`
* **XLM:** `GCYA45E2VUBE7ECCMXR4ZQGIOMY55KCF2L5FTZY4F6RMWLRVI74MKJ35`
* **ICP:** `d6f22202f1d33917858fd794bc65f2294dc61588fbfe88233958e08f1540ece8`